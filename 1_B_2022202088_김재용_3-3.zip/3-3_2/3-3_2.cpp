#include <iostream>
#include "class.h"
using namespace std;

int main() {
	Student a;
	Professor b;
	int age, schoolYear;
	char name[32];
	char psnum[11];
	char major[32];

	cin >> name >> age >> psnum;
	cin.ignore();
	cin.getline(major,32);
	cin >> schoolYear;		//Student �ȿ� �� ���� �Է�
	a.setName(name);
	a.setAge(age);
	a.setStudentNum(psnum);
	a.setMajor(major);
	a.setSchoolYear(schoolYear);

	cin >> name >> age >> psnum;					//Professor �ȿ� �� ���� �Է�
	cin.ignore();
	cin.getline(major, 32);
	b.setName(name);
	b.setAge(age);
	b.setProfessorNum(psnum);
	b.setMajor(major);
	
	cout << "\n";
	a.Say();			// Student ���
	cout << "\n";
	b.Say();			// Professor ���
}