class Student {		//Ŭ���� ���� �κ��� �ּ��� ������
private:
	char* name;
	int age;
	char* class_name;

public:
	Student();
	Student(char* name, int age, char* class_name);
	~Student();

	char* GetName();
	int GetAge();
	char* GetClass_Name();

	void ChangeName(char* name);
	void ChangeAge(int age);
	void ChangeClass_Name(char* class_name);
};

class School {
private:
	class Student* student_list[100];
	int size = 0;

public:
	School();
	
	~School();

	void insert_Student(char* name, int age, char* class_name);
	void print_all();
	void print_class(char* class_name);
	void sort_by_name();

};